﻿
namespace Core.DTOs
{
    public interface IConfigValidator
    {
        void validate();
    }
}
