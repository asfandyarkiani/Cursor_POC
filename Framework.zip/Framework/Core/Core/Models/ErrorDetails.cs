﻿namespace Core.Models
{
    public class ErrorDetails
    {
        public List<Step>? Errors { get; set; }
    }
}
