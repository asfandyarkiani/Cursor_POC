﻿
namespace Core.ProcessLayer.DTOs
{
    public interface IRequestBaseDTO
    {
        public void Validate();
    }
}
